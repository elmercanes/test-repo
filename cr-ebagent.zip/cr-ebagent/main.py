# main.py
import os
from fastapi import FastAPI
from google.adk.cli.fast_api import get_fast_api_app

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
# AGENTS_DIR=/app/orchestrator/sub_agents
AGENT_DIR = os.getenv("AGENT_DIR", "/app")

app: FastAPI = get_fast_api_app(
    agents_dir=AGENT_DIR,
    session_service_uri="sqlite:///./sessions.db",
    allow_origins=["*"],
    web=True,
)