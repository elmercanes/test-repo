import json
from unittest.mock import MagicMock, patch
import os

from orchestrator.callbacks.utils.cost_tracker import (
    TokenCostTracker,
    TokenUsage,
    CostCalculation,
    cost_tracker,
    configure_custom_model,
    export_costs,
    get_session_costs,
)


def test_extract_token_usage_various_formats():
    tracker = TokenCostTracker()

    # Simulate Google ADK usage_metadata using a plain object
    class UsageMeta:
        prompt_token_count = 5
        candidates_token_count = 3
        total_token_count = 8

    class RespA:
        usage_metadata = UsageMeta()

    resp = RespA()
    tu = tracker.extract_token_usage(resp)
    assert isinstance(tu, TokenUsage)
    assert tu.input_tokens == 5 and tu.output_tokens == 3 and tu.total_tokens == 8

    # Simulate OpenAI-like usage with a plain object
    class Usage:
        prompt_tokens = 10
        completion_tokens = 2
        total_tokens = 12

    class RespB:
        usage = Usage()

    resp2 = RespB()
    tu2 = tracker.extract_token_usage(resp2)
    assert tu2.input_tokens == 10 and tu2.output_tokens == 2 and tu2.total_tokens == 12

    # Simulate dict-like content with usage using plain object
    class RespC:
        content = {'usage': {'prompt_tokens': 7, 'completion_tokens': 1, 'total_tokens': 8}}

    resp3 = RespC()
    tu3 = tracker.extract_token_usage(resp3)
    assert tu3.input_tokens == 7 and tu3.output_tokens == 1 and tu3.total_tokens == 8

    # Non-recognized format returns None (actual implementation returns empty TokenUsage when attrs exist but are None)
    class RespD:
        usage = None
        usage_metadata = None
        content = None

    resp4 = RespD()
    tu4 = tracker.extract_token_usage(resp4)
    assert isinstance(tu4, TokenUsage)
    assert tu4.input_tokens == 0 and tu4.output_tokens == 0 and tu4.total_tokens == 0


def test_calculate_cost_known_and_unknown_model():
    tracker = TokenCostTracker()
    tu = TokenUsage(input_tokens=1000, output_tokens=500)

    cost = tracker.calculate_cost('gpt-4.1', tu)
    assert isinstance(cost, CostCalculation)
    assert cost.total_cost >= 0

    # Unknown model returns zero-cost CostCalculation
    cost2 = tracker.calculate_cost('non-existent-model', tu)
    assert cost2.total_cost == 0


def test_track_llm_call_updates_state(tmp_path):
    tracker = TokenCostTracker()
    # ensure clean state
    tracker.reset_session()

    # Create fake llm_response with usage attribute using a plain object (avoid MagicMock in call history)
    class Usage:
        prompt_tokens = 100
        completion_tokens = 50
        total_tokens = 150

    class RespObj:
        usage = Usage()

    resp = RespObj()

    record = tracker.track_llm_call('agent-a', 'gpt-4.1', resp)
    assert record is not None
    summary = tracker.get_session_summary()
    assert 'agent-a' in summary['cost_by_agent']
    assert summary['total_calls'] == 1

    # Export call history to a temp file and verify JSON
    out = tracker.export_call_history(str(tmp_path / 'out.json'))
    assert out.endswith('.json')
    with open(out, 'r', encoding='utf-8') as f:
        data = json.load(f)
    assert 'call_history' in data


def test_configure_custom_model_and_helpers():
    # configure new model and verify pricing accessible
    configure_custom_model('custom-model', 0.01, 0.02, provider='Test')
    info = cost_tracker.get_model_info('custom-model')
    assert info['provider'] == 'Test'

    # get_session_costs helper should return a dict
    costs = get_session_costs()
    assert isinstance(costs, dict)

    # export_costs helper (create temp file)
    from tempfile import NamedTemporaryFile
    tf = NamedTemporaryFile(delete=False)
    try:
        path = export_costs(tf.name)
        assert path == tf.name
    finally:
        try:
            os.remove(tf.name)
        except Exception:
            pass
