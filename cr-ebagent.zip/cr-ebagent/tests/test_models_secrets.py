import os
import sys
import importlib
import pytest
from unittest.mock import MagicMock, patch

def test_gcp_disabled_conditions(monkeypatch):
    """Verifica las diferentes condiciones que pueden deshabilitar GCP"""
    sys.modules.pop('orchestrator.model.models', None)
    
    test_cases = [
        {'SKIP_GCP_AUTH': '1', 'CI': '', 'PYTEST_CURRENT_TEST': ''},
        {'SKIP_GCP_AUTH': '0', 'CI': 'true', 'PYTEST_CURRENT_TEST': ''},
        {'SKIP_GCP_AUTH': '0', 'CI': '', 'PYTEST_CURRENT_TEST': 'test_something'},
    ]
    
    for case in test_cases:
        # Configurar variables de entorno para cada caso
        for k, v in case.items():
            monkeypatch.setenv(k, v)
        
        models = importlib.import_module('orchestrator.model.models')
        assert models._gcp_disabled() is True, f"GCP debería estar deshabilitado con {case}"

def test_project_id_resolution(monkeypatch):
    """Verifica la resolución del project_id desde diferentes fuentes"""
    sys.modules.pop('orchestrator.model.models', None)
    
    # Limpiar todas las variables de proyecto y secretos
    for k in list(os.environ.keys()):
        if any(k.startswith(prefix) for prefix in ['GOOGLE_', 'GCP_', 'PROJECT_', 'SALUD_', 'RAG_']):
            monkeypatch.delenv(k, raising=False)
    
    monkeypatch.setenv('SKIP_GCP_AUTH', '0')
    monkeypatch.setenv('CI', '')
    monkeypatch.delenv('PYTEST_CURRENT_TEST', raising=False)
    monkeypatch.setenv('GOOGLE_CLOUD_PROJECT', 'test-project')
    
    mock_resp = MagicMock()
    mock_resp.payload.data = b'secret-value'
    
    with patch('google.cloud.secretmanager.SecretManagerServiceClient') as MockClient:
        instance = MockClient.return_value
        instance.access_secret_version.return_value = mock_resp
        models = importlib.import_module('orchestrator.model.models')
        
        with patch.object(models, '_gcp_disabled', return_value=False):
            _ = models.get_litellm_model('gpt-4.1')
            
        # Verifica que al menos una llamada se hizo con el project_id correcto
        assert any('test-project' in call[1]['request']['name'] 
                  for call in instance.access_secret_version.call_args_list)
