import os
import sys
import importlib
import time
from unittest.mock import patch, MagicMock
import pytest


def _reload_prompt_module_with_env(env):
    sys.modules.pop('orchestrator.prompts.dynamic_prompt_manager', None)
    with patch.dict(os.environ, env, clear=False):
        return importlib.import_module('orchestrator.prompts.dynamic_prompt_manager')


def test_static_prompt_manager_success_and_missing():
    env = {
        'ORCHESTRATOR_TEMPERATURE': '0.5',
        'ORCHESTRATOR_MAX_OUTPUT_TOKENS': '50',
        'ORCHESTRATOR_TOP_K': '5',
        'ORCHESTRATOR_TOP_P': '0.9'
    }
    mod = _reload_prompt_module_with_env(env)
    # Ensure the environment is clean when building the prompt config
    with patch.dict(os.environ, env, clear=True):
        spm = mod.StaticPromptManager()
        cfg = spm.get_static_prompt_config('orchestrator', system_instruction='hello')
        assert cfg.system_instruction == 'hello'
        assert isinstance(cfg.temperature, float)
        assert isinstance(cfg.max_output_tokens, int)

    # missing params should raise
    with patch.dict(os.environ, {}, clear=True):
        mod2 = importlib.reload(importlib.import_module('orchestrator.prompts.dynamic_prompt_manager'))
        spm2 = mod2.StaticPromptManager()
        with pytest.raises(ValueError):
            spm2.get_static_prompt_config('orchestrator', system_instruction='')


def test_debug_after_model_with_function_call():
    # reload module to ensure clean globals
    sys.modules.pop('orchestrator.callbacks.debug', None)
    mod = importlib.import_module('orchestrator.callbacks.debug')

    # prepare fake callback context
    class FakeState:
        def to_dict(self):
            return {}

    class FakeSession:
        def __init__(self):
            self.id = 's'
            self.user_id = 'u'

    class FakeInvocation:
        def __init__(self):
            self.session = FakeSession()

    class FakeCallbackContext:
        def __init__(self):
            self.agent_name = 'agent-x'
            self.invocation_id = 'inv-1'
            self.state = FakeState()
            self._invocation_context = FakeInvocation()

    ctx = FakeCallbackContext()

    # fake llm request
    class FakeLlmRequest:
        def __init__(self):
            self.contents = [MagicMock(parts=[MagicMock(text='hi')])]
            self.config = None
            self.model = 'gpt-4.1'

    # fake llm response with a function_call inside parts
    class Part:
        def __init__(self):
            self.text = 'out'
            fc = MagicMock()
            fc.name = 'fn1'
            self.function_call = fc

    class FakeContent:
        def __init__(self):
            self.parts = [Part()]

    class FakeLlmResponse:
        def __init__(self):
            self.content = FakeContent()
            self.usage_metadata = None

    req = FakeLlmRequest()
    resp = FakeLlmResponse()

    # patch track_model_call to return None
    with patch('orchestrator.callbacks.debug.track_model_call', return_value=None):
        assert mod.debug_before_model_callback(ctx, req) is None
        assert mod.debug_after_model_callback(ctx, resp) is None
