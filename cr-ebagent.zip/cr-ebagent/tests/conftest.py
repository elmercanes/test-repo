# tests/conftest.py
import sys
from pathlib import Path
import os

# 1) Sembrar env ANTES de importar cualquier test/módulo
os.environ.setdefault("SKIP_GCP_AUTH", "1")
os.environ.setdefault("CI", "true")

# 2) Ajustar sys.path después (opcional)
ROOT = Path(__file__).resolve().parents[1]  # -> cr-quantum-agent
sys.path.insert(0, str(ROOT))

# (no uses fixture para esto)
