import os
import sys
import importlib
import pytest
from unittest.mock import patch, MagicMock


def test_get_litellm_model_and_default_model():
    """Verifica que `get_litellm_model` retorne la instancia y que `default_model` inicialice lazy."""
    # Sembrar entorno CI-safe ANTES de importar el módulo
    os.environ.setdefault("SKIP_GCP_AUTH", "1")
    os.environ.setdefault("CI", "true")

    # Forzar reimport limpio del módulo bajo prueba
    sys.modules.pop('orchestrator.model.models', None)

    mock_resp = MagicMock()
    mock_resp.payload.data = b'secret-value'

    with patch('google.adk.models.lite_llm.LiteLlm') as MockLite:
        MockLite.return_value = 'lite-instance'
        with patch('google.cloud.secretmanager.SecretManagerServiceClient') as MockClient:
            instance = MockClient.return_value
            instance.secret_version_path.return_value = 'projects/fake/secret/versions/latest'
            instance.access_secret_version.return_value = mock_resp

            models = importlib.import_module('orchestrator.model.models')

    # get_litellm_model debe crear y devolver la instancia mockeada
    assert models.get_litellm_model('vertex_ai/gemini-2.5-flash') == 'lite-instance'

    # default_model es un proxy perezoso: materializa explícitamente
    assert isinstance(models.default_model, models._LazyModel)
    assert models.default_model._get() == 'lite-instance'  # fuerza la creación y comprueba

    # litellm proxy flag debe estar activado
    import litellm
    assert litellm.use_litellm_proxy is False


def test_secretsmanager_raises_on_access_error():
    """Verifica la rama de excepción de SecretsManager.get_secret_payload."""
    from orchestrator.model.models import SecretsManager

    with patch('google.cloud.secretmanager.SecretManagerServiceClient') as MockClient:
        instance = MockClient.return_value
        instance.secret_version_path.return_value = 'p/f/s/v'
        instance.access_secret_version.side_effect = Exception('access denied')

        sm = SecretsManager('some-project')
        with pytest.raises(Exception):
            sm.get_secret_payload('NAME')
