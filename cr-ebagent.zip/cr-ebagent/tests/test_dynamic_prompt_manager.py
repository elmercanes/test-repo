import importlib
import sys
import os
from unittest.mock import patch, MagicMock


def _reload_module_with_env(env: dict):
    # Ensure fresh import of the module under test with controlled env
    sys.modules.pop('orchestrator.prompts.dynamic_prompt_manager', None)
    with patch.dict(os.environ, env, clear=False):
        return importlib.import_module('orchestrator.prompts.dynamic_prompt_manager')


def test_get_prompt_config_success():
    env = {'ORCHESTRATOR_AGENT_INSTRUCTION': 'projects/xxx/locations/yyy/prompts/orch'}

    # Create a fake prompt object as returned by vertexai.preview.prompts.get
    class GenCfg:
        temperature = 0.2
        max_output_tokens = 128
        top_k = 5
        top_p = 0.9

    fake_prompt = MagicMock()
    fake_prompt.system_instruction = 'You are an orchestrator.'
    fake_prompt.generation_config = GenCfg()

    with patch('orchestrator.prompts.dynamic_prompt_manager.prompts.get', return_value=fake_prompt):
        mod = _reload_module_with_env(env)
        cfg = mod.dynamic_prompt_manager.get_prompt_config('orchestrator')

    assert cfg.system_instruction == 'You are an orchestrator.'
    assert cfg.temperature == 0.2
    assert cfg.max_output_tokens == 128
    assert cfg.top_k == 5
    assert cfg.top_p == 0.9


def test_get_prompt_config_fallback_on_missing_id_or_error():
    # No env entry -> fallback
    env = {'ORCHESTRATOR_AGENT_INSTRUCTION': ''}
    mod = _reload_module_with_env(env)
    cfg = mod.dynamic_prompt_manager.get_prompt_config('orchestrator')
    assert 'orchestrator' in cfg.system_instruction.lower() or len(cfg.system_instruction) > 0

    # If prompts.get raises, fallback should be returned
    env2 = {'ORCHESTRATOR_AGENT_INSTRUCTION': 'id/that/will/fail'}
    with patch('orchestrator.prompts.dynamic_prompt_manager.prompts.get', side_effect=Exception('fail')):
        mod2 = _reload_module_with_env(env2)
        cfg2 = mod2.dynamic_prompt_manager.get_prompt_config('orchestrator')
    assert 'orchestrator' in cfg2.system_instruction.lower() or len(cfg2.system_instruction) > 0


def test_dynamic_instruction_providers_return_values():
    env = {'ORCHESTRATOR_AGENT_INSTRUCTION': 'projects/xxx/locations/yyy/prompts/orch'}

    class GenCfg:
        temperature = 0.33
        max_output_tokens = 64
        top_k = 3
        top_p = 0.8

    fake_prompt = MagicMock()
    fake_prompt.system_instruction = 'Dynamic orchestrator prompt.'
    fake_prompt.generation_config = GenCfg()

    with patch('orchestrator.prompts.dynamic_prompt_manager.prompts.get', return_value=fake_prompt):
        mod = _reload_module_with_env(env)
        instr_provider = mod.dynamic_prompt_manager.get_dynamic_instruction('orchestrator')
        cfg_provider = mod.dynamic_prompt_manager.get_dynamic_instruction_with_config('orchestrator')

        # calling providers should return the expected values
        instr = instr_provider()
        cfg = cfg_provider()

    assert instr == 'Dynamic orchestrator prompt.'
    assert cfg.system_instruction == 'Dynamic orchestrator prompt.'
    assert cfg.temperature == 0.33


def test_get_generation_config_dict_variants():
    env = {'ORCHESTRATOR_AGENT_INSTRUCTION': 'projects/xxx/locations/yyy/prompts/orch'}

    class GenCfgPartial:
        temperature = None
        max_output_tokens = None
        top_k = None
        top_p = None

    fake_prompt = MagicMock()
    fake_prompt.system_instruction = 'Instr'
    fake_prompt.generation_config = GenCfgPartial()

    with patch('orchestrator.prompts.dynamic_prompt_manager.prompts.get', return_value=fake_prompt):
        mod = _reload_module_with_env(env)
        cfg = mod.dynamic_prompt_manager.get_prompt_config('orchestrator')
        gd = mod.dynamic_prompt_manager.get_generation_config_dict('orchestrator')
    # gd should be an empty dict when generation config values are None
    assert isinstance(gd, dict)
    assert gd == {}
