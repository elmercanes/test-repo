import sys
import importlib
from unittest.mock import patch, MagicMock
import json
import time


def _import_debug_with_open_error():
    # Ensure a clean import and force get_version fallback by making open raise FileNotFoundError
    sys.modules.pop('orchestrator.callbacks.debug', None)
    with patch('builtins.open', side_effect=FileNotFoundError()), \
         patch('google.cloud.logging.Client') as MockClient, \
         patch('google.cloud.logging.Resource') as MockResource:
        MockClient.return_value = MagicMock()
        module = importlib.import_module('orchestrator.callbacks.debug')
    return module


def test_get_peru_timestamp_and_version_fallback():
    mod = _import_debug_with_open_error()
    ts = mod.get_peru_timestamp()
    assert isinstance(ts, str) and len(ts) > 0

    # VERSION should fallback to unknown_version because we forced open() to fail
    assert getattr(mod, 'VERSION', None) == 'unknown_version'


def test_debug_logger_timing_and_event_logging():
    mod = _import_debug_with_open_error()
    # reset global logger instance
    mod.debug_logger = mod.DebugLogger()

    # Log event
    mod.debug_logger.log_event('TEST_EVENT', {'a': 1}, level='INFO')
    assert len(mod.debug_logger.logs) == 1

    # Timing
    mod.debug_logger.start_timing('op')
    time.sleep(0.001)
    duration = mod.debug_logger.end_timing('op')
    assert duration >= 0

    # Update metrics
    mod.debug_logger.metrics['total_calls'] = 1
    mod.debug_logger.update_metrics('avg_response_time', 0.5)
    # avg_response_time calculation should not raise and be a float
    assert isinstance(mod.debug_logger.metrics['avg_response_time'], float)


def test_agent_model_and_tool_callbacks_work_flow():
    mod = _import_debug_with_open_error()
    # reset debug logger
    mod.debug_logger = mod.DebugLogger()

    # Create a fake callback context with nested invocation/session
    class FakeSession:
        def __init__(self):
            self.id = 'sess1'
            self.user_id = 'user1'

    class FakeInvocationContext:
        def __init__(self):
            self.session = FakeSession()

    class FakeState:
        def to_dict(self):
            return {'k': 'v'}

    class FakeCallbackContext:
        def __init__(self):
            self.agent_name = 'agent-x'
            self.invocation_id = 'inv-1'
            self.state = FakeState()
            self._invocation_context = FakeInvocationContext()

    ctx = FakeCallbackContext()

    # Agent callbacks
    assert mod.debug_before_agent_callback(ctx) is None
    assert mod.debug_after_agent_callback(ctx) is None

    # Model callbacks: create fake LlmRequest and LlmResponse
    class FakePart:
        def __init__(self, text):
            self.text = text
            self.function_call = None

    class FakeContent:
        def __init__(self, text):
            self.parts = [FakePart(text)]

    class FakeConfig:
        def __init__(self):
            self.temperature = 0.1
            self.max_output_tokens = 10

    class FakeLlmRequest:
        def __init__(self):
            self.contents = [MagicMock(parts=[MagicMock(text='hello')])]
            self.config = FakeConfig()
            self.model = 'gpt-4.1'

    class FakeLlmResponse:
        def __init__(self):
            self.content = MagicMock(parts=[MagicMock(text='resp')])
            self.usage_metadata = None

    req = FakeLlmRequest()
    resp = FakeLlmResponse()

    # Patch track_model_call to return fake cost info
    with patch('orchestrator.callbacks.debug.track_model_call', return_value={
        'token_usage': {'input_tokens': 10, 'output_tokens': 5, 'total_tokens': 15},
        'costs': {'total_cost': 0.001}
    }):
        assert mod.debug_before_model_callback(ctx, req) is None
        assert mod.debug_after_model_callback(ctx, resp) is None

    # Tool callbacks
    class FakeTool:
        def __init__(self):
            self.name = 'tool1'

    class FakeToolContext:
        def __init__(self):
            self.agent_name = 'agent-x'
            self.invocation_id = 'inv-tool'
            self.state = FakeState()
            self._invocation_context = FakeInvocationContext()

    tool = FakeTool()
    tctx = FakeToolContext()

    assert mod.debug_before_tool_callback(tool, {'a': 1}, tctx) is None
    # successful response
    assert mod.debug_after_tool_callback(tool, {'a': 1}, tctx, {'ok': True}) is None
    # error response should increment errors metric (no exception)
    mod.debug_logger = mod.DebugLogger()
    mod.debug_before_tool_callback(tool, {'a': 1}, tctx)
    assert mod.debug_after_tool_callback(tool, {'a': 1}, tctx, {'error': 'fail'}) is None
