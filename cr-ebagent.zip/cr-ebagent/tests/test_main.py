"""Pruebas unitarias para main.py."""
import os
import pytest
from fastapi import FastAPI
from unittest.mock import patch, MagicMock
from main import app


def test_app_creation():
    """Prueba que la aplicación FastAPI se crea correctamente."""
    assert isinstance(app, FastAPI)
    assert app.title is not None  # Verifica que tenga un título


def test_base_dir():
    """Prueba que BASE_DIR esté configurado correctamente."""
    from main import BASE_DIR
    assert os.path.exists(BASE_DIR)
    assert os.path.isdir(BASE_DIR)

"""
def test_agent_dir_from_env():
    Prueba que AGENT_DIR use la ruta fija `/app/orchestrator/sub_agents`.
    fixed_dir = "/app/orchestrator/sub_agents"
    # Establecer la variable de entorno con la misma clave que usa el módulo (cadena de la ruta)
    with patch.dict(os.environ, {"/app/orchestrator/sub_agents": fixed_dir}):
        import importlib
        import main
        importlib.reload(main)
        from main import AGENT_DIR
        assert AGENT_DIR == fixed_dir
"""

@patch('google.adk.cli.fast_api.get_fast_api_app')
def test_get_fast_api_app_called_with_correct_params(mock_get_app):
    """Prueba que get_fast_api_app se llama con los parámetros correctos."""
    mock_app = MagicMock()
    mock_get_app.return_value = mock_app

    # Recarga para forzar la creación de la app
    import importlib
    import main
    importlib.reload(main)

    from main import AGENT_DIR

    mock_get_app.assert_called_once_with(
        agents_dir=AGENT_DIR,
        session_service_uri="sqlite:///./sessions.db",
        allow_origins=["*"],
        web=True,
    )