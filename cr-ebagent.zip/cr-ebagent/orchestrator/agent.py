from google.adk.planners import BuiltInPlanner
from google.genai import types
from google.adk.agents import LlmAgent
from orchestrator.model.models import get_litellm_model
from orchestrator import prompt
from orchestrator.prompts.static_prompt_manager import static_prompt_manager

from .callbacks.debug import (
     debug_after_agent_callback,
     debug_before_agent_callback,
     debug_after_model_callback,
     debug_before_model_callback,
 )

NAME = "orchestrator"
config = static_prompt_manager.get_static_prompt_config(NAME, prompt.ORCHESTRATOR_PROMPT)
no_thinking_config = BuiltInPlanner(thinking_config=types.ThinkingConfig(thinking_budget=0))

root_agent = LlmAgent(
    model=get_litellm_model("vertex_ai/gemini-2.5-flash"),
    name=NAME,
    description="Orquestador inteligente que enruta consultas a agentes especializados de Rimac",
    instruction=prompt.ORCHESTRATOR_PROMPT,
    generate_content_config=types.GenerateContentConfig(
        temperature=config.temperature, 
        max_output_tokens=config.max_output_tokens,
        top_p=config.top_p
    ),
    planner = no_thinking_config,
    before_agent_callback=debug_before_agent_callback,
    after_agent_callback=debug_after_agent_callback,
    before_model_callback=debug_before_model_callback,
    after_model_callback=debug_after_model_callback
)