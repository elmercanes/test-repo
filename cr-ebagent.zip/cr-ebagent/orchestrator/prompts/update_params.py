import os
import vertexai 
from vertexai.preview import prompts 
from vertexai.preview.prompts import Prompt 
from vertexai.generative_models import GenerationConfig

PROJECT_ID=os.getenv('PROJECT_ID', '')
LOCATION=os.getenv('LOCATION', 'us-central1')
ORCHESTRATOR_AGENT_INSTRUCTION=os.getenv('ORCHESTRATOR_AGENT_INSTRUCTION', '')

vertexai.init(project=PROJECT_ID, location=LOCATION)

def create_prompt_version(prompt_id: str, temperature: float = 0.2, max_tokens: int = 2048, 
                         top_p: float = 0.95, top_k: int = 20):
    """Create new version of existing prompt with updated parameters"""
    
    vertexai.init(project=PROJECT_ID, location=LOCATION)
    
    try:
        # Get existing prompt
        prompt = prompts.get(prompt_id)

        # Generate content using the assembled prompt (a prompt without variables)
        prompt.generate_content(
          contents=prompt.assemble_contents()
        )
        
        # Update generation config
        prompt.generation_config.temperature = temperature
        prompt.generation_config.max_output_tokens = max_tokens
        prompt.generation_config.top_k = top_k
        prompt.generation_config.top_p = top_p
        
        # Create new version
        new_prompt = prompts.create_version(prompt=prompt)
        print(f" - Created new version prompt: {new_prompt.prompt_id}")
        
        return new_prompt.prompt_id
        
    except Exception as e:
        print(f"Error: {e}")
        return None

def main():

  create_prompt_version(ORCHESTRATOR_AGENT_INSTRUCTION)

if __name__ == "__main__":
  main()