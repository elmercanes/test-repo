"""
Dynamic Prompt Manager for Real-time Prompt Updates
No caching - fetches fresh prompts from Vertex AI on every request
"""
import os
from dotenv import load_dotenv
from typing import Optional, Dict, Any
from vertexai.preview import prompts
from dataclasses import dataclass
import logging

load_dotenv()

logger = logging.getLogger(__name__)

@dataclass
class PromptConfig:
    """Structure to hold prompt instruction and generation configuration."""
    system_instruction: str
    temperature: Optional[float] = None
    max_output_tokens: Optional[int] = None
    top_k: Optional[int] = None
    top_p: Optional[float] = None

class StaticPromptManager:
    """
    Manager for static prompt loading without caching.
    """
    
    def __init__(self):
        self.prompt_mapping = {
            'orchestrator': os.getenv('ORCHESTRATOR_AGENT_INSTRUCTION', ''),
        }
    
    def get_static_prompt_config(self, agent_name: str, system_instruction: str) -> PromptConfig:
        """
        Builds system instruction and generation config from local .env variables.
        All parameters are mandatory; raises ValueError if any are missing.
        
        Args:
            agent_name: Name of the agent requesting the prompt
            
        Returns:
            PromptConfig with instruction and generation parameters
        
        Raises:
            ValueError: If any required parameter is missing
        """
        prefix = agent_name.upper()
        temperature = os.getenv(f"{prefix}_TEMPERATURE")
        max_output_tokens = os.getenv(f"{prefix}_MAX_OUTPUT_TOKENS")
        top_k = os.getenv(f"{prefix}_TOP_K")
        top_p = os.getenv(f"{prefix}_TOP_P")

        missing = []
        if not system_instruction:
            missing.append("system_instruction")
        if temperature is None:
            missing.append(f"{prefix}_TEMPERATURE")
        if max_output_tokens is None:
            missing.append(f"{prefix}_MAX_OUTPUT_TOKENS")
        if top_k is None:
            missing.append(f"{prefix}_TOP_K")
        if top_p is None:
            missing.append(f"{prefix}_TOP_P")

        if missing:
            raise ValueError(f"Missing mandatory parameters for agent '{agent_name}': {', '.join(missing)}")

        config = PromptConfig(
            system_instruction=system_instruction,
            temperature=float(temperature),
            max_output_tokens=int(max_output_tokens),
            top_k=int(top_k),
            top_p=float(top_p)
        )

        logger.debug(f"[{agent_name}] Static prompt and config loaded from .env")
        return config
    
class DynamicPromptManager:
    """
    Manager for dynamic prompt loading without caching.
    Each request fetches the latest prompt from Vertex AI.
    """
    
    def __init__(self):
        self.prompt_mapping = {
            'orchestrator': os.getenv('ORCHESTRATOR_AGENT_INSTRUCTION', '')
        }
    
    def get_static_prompt_config(self, agent_name: str, system_instruction: str) -> PromptConfig:
        """
        Builds system instruction and generation config from local .env variables.
        All parameters are mandatory; raises ValueError if any are missing.
        
        Args:
            agent_name: Name of the agent requesting the prompt
            
        Returns:
            PromptConfig with instruction and generation parameters
        
        Raises:
            ValueError: If any required parameter is missing
        """
        prefix = agent_name.upper()
        temperature = os.getenv(f"{prefix}_TEMPERATURE")
        max_output_tokens = os.getenv(f"{prefix}_MAX_OUTPUT_TOKENS")
        top_k = os.getenv(f"{prefix}_TOP_K")
        top_p = os.getenv(f"{prefix}_TOP_P")

        missing = []
        if not system_instruction:
            missing.append("system_instruction")
        if temperature is None:
            missing.append(f"{prefix}_TEMPERATURE")
        if max_output_tokens is None:
            missing.append(f"{prefix}_MAX_OUTPUT_TOKENS")
        if top_k is None:
            missing.append(f"{prefix}_TOP_K")
        if top_p is None:
            missing.append(f"{prefix}_TOP_P")

        if missing:
            raise ValueError(f"Missing mandatory parameters for agent '{agent_name}': {', '.join(missing)}")

        config = PromptConfig(
            system_instruction=system_instruction,
            temperature=float(temperature),
            max_output_tokens=int(max_output_tokens),
            top_k=int(top_k),
            top_p=float(top_p)
        )

        logger.debug(f"[{agent_name}] Static prompt and config loaded from .env")
        return config
        
    def get_prompt_config(self, agent_name: str) -> PromptConfig:
        """
        Fetches both system instruction and generation config from Vertex AI.
        
        Args:
            agent_name: Name of the agent requesting the prompt
            
        Returns:
            PromptConfig with instruction and generation parameters
        """
        try:
            prompt_id = self.prompt_mapping.get(agent_name)
            
            if not prompt_id:
                logger.warning(f"No prompt ID configured for agent: {agent_name}")
                return self._get_fallback_config(agent_name)
            
            # Fetch fresh prompt from Vertex AI
            prompt = prompts.get(prompt_id)
            
            config = PromptConfig(
                system_instruction=prompt.system_instruction,
                temperature=getattr(prompt.generation_config, 'temperature', None),
                max_output_tokens=getattr(prompt.generation_config, 'max_output_tokens', None),
                top_k=getattr(prompt.generation_config, 'top_k', None),
                top_p=getattr(prompt.generation_config, 'top_p', None)
            )
            
            logger.debug(f"[{agent_name}] Fresh prompt and config fetched from Vertex AI")
            
            return config
            
        except Exception as e:
            logger.error(f"Error fetching prompt config for {agent_name}: {e}")
            return self._get_fallback_config(agent_name)
    
    def get_dynamic_instruction_with_config(self, agent_name: str):
        """
        Returns a function that ADK will call on each request.
        This function fetches fresh prompt and config from Vertex AI every time.
        
        Args:
            agent_name: Name of the agent requesting the prompt
            
        Returns:
            A function that returns the current PromptConfig
        """
        def config_provider(ctx=None):
            """
            Provider function called by ADK on each request.
            Fetches fresh prompt and config without any caching.
            """
            return self.get_prompt_config(agent_name)
        
        return config_provider
    
    def get_dynamic_instruction(self, agent_name: str):
        """
        Returns a function that ADK will call on each request for system instruction only.
        Maintains backward compatibility with original dynamic_prompt_manager.
        
        Args:
            agent_name: Name of the agent requesting the prompt
            
        Returns:
            A function that returns the current prompt instruction
        """
        def instruction_provider(ctx=None):
            """
            Provider function called by ADK on each request.
            Fetches fresh prompt without any caching.
            """
            config = self.get_prompt_config(agent_name)
            return config.system_instruction
        
        return instruction_provider
    
    def _get_fallback_config(self, agent_name: str) -> PromptConfig:
        """
        Provides fallback instruction when Vertex AI is unavailable.
        Generation config parameters are not set in fallbacks (managed remotely).
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            PromptConfig with fallback instruction only
        """
        fallback_instructions = {
            'orchestrator': "You are an intelligent orchestrator that routes queries to specialized Rimac insurance agents.",
        }
        
        instruction = fallback_instructions.get(
            agent_name,
            f"You are the {agent_name} agent. Process requests according to your configuration."
        )
        
        # No default generation config values - managed remotely
        return PromptConfig(system_instruction=instruction)
    
    def get_static_instruction(self, agent_name: str) -> str:
        """
        Gets a single static instruction (for backward compatibility).
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            Current prompt instruction as a string
        """
        config = self.get_prompt_config(agent_name)
        return config.system_instruction
    
    def get_generation_config_dict(self, agent_name: str) -> Dict[str, Any]:
        """
        Gets generation configuration as a dictionary.
        
        Args:
            agent_name: Name of the agent
            
        Returns:
            Dictionary with generation config parameters
        """
        config = self.get_prompt_config(agent_name)
        
        config_dict = {}
        if config.temperature is not None:
            config_dict['temperature'] = config.temperature
        if config.max_output_tokens is not None:
            config_dict['max_output_tokens'] = config.max_output_tokens
        if config.top_k is not None:
            config_dict['top_k'] = config.top_k
        if config.top_p is not None:
            config_dict['top_p'] = config.top_p
            
        return config_dict

# Singleton instance
dynamic_prompt_manager = DynamicPromptManager()