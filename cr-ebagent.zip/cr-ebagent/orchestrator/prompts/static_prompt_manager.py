"""
Static Prompt Manager
No caching - fetches  prompts from .env
"""
import os
from dotenv import load_dotenv
from typing import Optional, Dict, Any
import logging
from .dynamic_prompt_manager import PromptConfig

load_dotenv(override=True)

logger = logging.getLogger(__name__)

class StaticPromptManager:
    """
    Manager for static prompt loading without caching.
    """
    
    def __init__(self):
        self.prompt_mapping = {
            'orchestrator': os.getenv('ORCHESTRATOR_AGENT_INSTRUCTION', '')
        }
    
    def get_static_prompt_config(self, agent_name: str, system_instruction: str) -> PromptConfig:
        """
        Builds system instruction and generation config from local .env variables.
        All parameters are mandatory; raises ValueError if any are missing.
        
        Args:
            agent_name: Name of the agent requesting the prompt
            
        Returns:
            PromptConfig with instruction and generation parameters
        
        Raises:
            ValueError: If any required parameter is missing
        """
        prefix = agent_name.upper()
        temperature = os.getenv(f"{prefix}_TEMPERATURE")
        max_output_tokens = os.getenv(f"{prefix}_MAX_OUTPUT_TOKENS")
        top_k = os.getenv(f"{prefix}_TOP_K")
        top_p = os.getenv(f"{prefix}_TOP_P")

        missing = []
        if not system_instruction:
            missing.append("system_instruction")
        if temperature is None:
            missing.append(f"{prefix}_TEMPERATURE")
        if max_output_tokens is None:
            missing.append(f"{prefix}_MAX_OUTPUT_TOKENS")
        if top_k is None:
            missing.append(f"{prefix}_TOP_K")
        if top_p is None:
            missing.append(f"{prefix}_TOP_P")

        if missing:
            raise ValueError(f"Missing mandatory parameters for agent '{agent_name}': {', '.join(missing)}")

        config = PromptConfig(
            system_instruction=system_instruction,
            temperature=float(temperature),
            max_output_tokens=int(max_output_tokens),
            top_k=top_k,
            top_p=top_p
        )

        logger.debug(f"[{agent_name}] Static prompt and config loaded from .env")
        return config

# Singleton instance
static_prompt_manager = StaticPromptManager()