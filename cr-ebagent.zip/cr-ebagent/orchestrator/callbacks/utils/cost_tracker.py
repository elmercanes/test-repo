import os
import logging
from typing import Dict, Optional, Tuple, Any
from dataclasses import dataclass
from datetime import datetime
import json

logger = logging.getLogger(__name__)

@dataclass
class TokenUsage:
    """Estructura para almacenar información de uso de tokens."""
    input_tokens: int = 0
    output_tokens: int = 0
    total_tokens: int = 0
    
    def __post_init__(self):
        if self.total_tokens == 0:
            self.total_tokens = self.input_tokens + self.output_tokens

@dataclass
class CostCalculation:
    """Estructura para almacenar cálculos de costo."""
    input_cost: float = 0.0
    output_cost: float = 0.0
    total_cost: float = 0.0
    model_name: str = ""
    timestamp: str = ""
    
    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now().isoformat()
        if self.total_cost == 0.0:
            self.total_cost = self.input_cost + self.output_cost

class TokenCostTracker:
    """Gestor de costos de tokens para diferentes modelos LLM."""
    
    def __init__(self):
        """Inicializa el tracker con precios desde variables de entorno o valores por defecto."""
        self.model_pricing = self._load_model_pricing()
        self.session_costs = {}
        self.total_session_cost = 0.0
        self.call_history = []
        
# Remover log de inicialización
    
    def _load_model_pricing(self) -> Dict[str, Dict[str, float]]:
        """Carga precios de modelos desde variables de entorno o usa valores por defecto."""
        pricing = {
            'gpt-4.1': {
                'input_cost_per_1k': float(os.getenv('GPT_4_1_INPUT_COST_1K', '0.002')),
                'output_cost_per_1k': float(os.getenv('GPT_4_1_OUTPUT_COST_1K', '0.008')),
                'provider': 'OpenAI'
            },
            'gemini-2.5-flash': {
                'input_cost_per_1k': float(os.getenv('GEMINI_2_5_FLASH_INPUT_COST_1K', '0.0003')),
                'output_cost_per_1k': float(os.getenv('GEMINI_2_5_FLASH_OUTPUT_COST_1K', '0.0025')),
                'provider': 'Google'
            }
        }
        
        return pricing
    
    def extract_token_usage(self, llm_response: Any) -> Optional[TokenUsage]:
        """Extrae información real de tokens de la respuesta LLM."""
        try:
            # Para respuestas de Google ADK (LlmResponse)
            if hasattr(llm_response, 'usage_metadata') and llm_response.usage_metadata:
                usage = llm_response.usage_metadata
                return TokenUsage(
                    input_tokens=getattr(usage, 'prompt_token_count', 0),
                    output_tokens=getattr(usage, 'candidates_token_count', 0),
                    total_tokens=getattr(usage, 'total_token_count', 0)
                )
            
            # Para respuestas de LiteLLM/OpenAI
            elif hasattr(llm_response, 'usage'):
                usage = llm_response.usage
                return TokenUsage(
                    input_tokens=getattr(usage, 'prompt_tokens', 0),
                    output_tokens=getattr(usage, 'completion_tokens', 0),
                    total_tokens=getattr(usage, 'total_tokens', 0)
                )
            
            # Para respuestas que tienen la estructura en un dict
            elif hasattr(llm_response, 'content') and isinstance(llm_response.content, dict):
                if 'usage' in llm_response.content:
                    usage = llm_response.content['usage']
                    return TokenUsage(
                        input_tokens=usage.get('prompt_tokens', 0),
                        output_tokens=usage.get('completion_tokens', 0),
                        total_tokens=usage.get('total_tokens', 0)
                    )
            
            logger.debug("No se pudo extraer información de tokens de la respuesta")
            return None
            
        except Exception as e:
            logger.warning(f"Error extrayendo tokens: {e}")
            return None
    
    def calculate_cost(self, model_name: str, token_usage: TokenUsage) -> CostCalculation:
        """Calcula el costo basado en el uso de tokens y el modelo."""
        if model_name not in self.model_pricing:
            logger.warning(f"Modelo '{model_name}' no encontrado en precios, usando costo 0")
            return CostCalculation(model_name=model_name)
        
        pricing = self.model_pricing[model_name]
        
        # Calcular costos (precios están por 1k tokens)
        input_cost = (token_usage.input_tokens / 1000.0) * pricing['input_cost_per_1k']
        output_cost = (token_usage.output_tokens / 1000.0) * pricing['output_cost_per_1k']
        
        cost_calc = CostCalculation(
            input_cost=round(input_cost, 6),
            output_cost=round(output_cost, 6),
            total_cost=round(input_cost + output_cost, 6),
            model_name=model_name
        )
        
        return cost_calc
    
    def track_llm_call(self, agent_name: str, model_name: str, llm_response: Any) -> Optional[Dict[str, Any]]:
        """Trackea una llamada LLM completa y retorna métricas de costo."""
        # Extraer tokens reales
        token_usage = self.extract_token_usage(llm_response)
        if not token_usage:
            logger.debug(f"No se pudieron extraer tokens para {model_name}")
            return None
        
        # Calcular costos
        cost_calc = self.calculate_cost(model_name, token_usage)
        
        # Actualizar totales de sesión
        if agent_name not in self.session_costs:
            self.session_costs[agent_name] = {'total_cost': 0.0, 'calls': 0}
        
        self.session_costs[agent_name]['total_cost'] += cost_calc.total_cost
        self.session_costs[agent_name]['calls'] += 1
        self.total_session_cost += cost_calc.total_cost
        
        # Guardar en historial
        call_record = {
            'timestamp': cost_calc.timestamp,
            'agent_name': agent_name,
            'model_name': model_name,
            'token_usage': {
                'input_tokens': token_usage.input_tokens,
                'output_tokens': token_usage.output_tokens,
                'total_tokens': token_usage.total_tokens
            },
            'costs': {
                'input_cost': cost_calc.input_cost,
                'output_cost': cost_calc.output_cost,
                'total_cost': cost_calc.total_cost
            },
            'session_total': self.total_session_cost
        }
        
        self.call_history.append(call_record)
        
        return call_record
    
    def get_session_summary(self) -> Dict[str, Any]:
        """Obtiene resumen de costos de la sesión actual."""
        return {
            'total_session_cost': round(self.total_session_cost, 6),
            'cost_by_agent': {
                agent: {
                    'total_cost': round(data['total_cost'], 6),
                    'calls': data['calls'],
                    'avg_cost_per_call': round(data['total_cost'] / data['calls'], 6) if data['calls'] > 0 else 0
                }
                for agent, data in self.session_costs.items()
            },
            'total_calls': len(self.call_history),
            'models_used': list(set(call['model_name'] for call in self.call_history))
        }
    
    def get_model_info(self, model_name: str) -> Dict[str, Any]:
        """Obtiene información de precios de un modelo."""
        if model_name in self.model_pricing:
            return self.model_pricing[model_name].copy()
        return {}
    
    def export_call_history(self, filepath: Optional[str] = None) -> str:
        """Exporta el historial de llamadas a un archivo JSON."""
        if not filepath:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            filepath = f"/tmp/llm_cost_history_{timestamp}.json"
        
        export_data = {
            'export_timestamp': datetime.now().isoformat(),
            'session_summary': self.get_session_summary(),
            'call_history': self.call_history,
            'model_pricing': self.model_pricing
        }
        
        try:
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, indent=2, ensure_ascii=False)
            logger.info(f"📊 Historial de costos exportado a: {filepath}")
            return filepath
        except Exception as e:
            logger.error(f"Error exportando historial: {e}")
            return ""
    
    def reset_session(self):
        """Reinicia los contadores de la sesión actual."""
        self.session_costs.clear()
        self.total_session_cost = 0.0
        self.call_history.clear()
        logger.info("🔄 Sesión de costos reiniciada")

# Instancia global del tracker
cost_tracker = TokenCostTracker()

# Funciones de utilidad para integración fácil
def track_model_call(agent_name: str, model_name: str, llm_response: Any) -> Optional[Dict[str, Any]]:
    """Función helper para trackear una llamada desde cualquier callback."""
    return cost_tracker.track_llm_call(agent_name, model_name, llm_response)

def get_session_costs() -> Dict[str, Any]:
    """Función helper para obtener resumen de costos de sesión."""
    return cost_tracker.get_session_summary()

def export_costs(filepath: Optional[str] = None) -> str:
    """Función helper para exportar historial de costos."""
    return cost_tracker.export_call_history(filepath)

# Configuración adicional desde variables de entorno
def configure_custom_model(model_name: str, input_cost_1k: float, output_cost_1k: float, provider: str = "Custom"):
    """Configura un modelo personalizado dinámicamente."""
    cost_tracker.model_pricing[model_name] = {
        'input_cost_per_1k': input_cost_1k,
        'output_cost_per_1k': output_cost_1k,
        'provider': provider
    }
    logger.info(f"🆕 Modelo personalizado configurado: {model_name} ({provider})")
