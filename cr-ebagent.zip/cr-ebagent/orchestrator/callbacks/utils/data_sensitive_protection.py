from typing import Any, Dict, Iterable, List, Optional, Tuple

from google.cloud import dlp_v2
from orchestrator.config.config import config


class DataSensitiveProtector:
    """Clase para protección de datos sensibles usando Google Cloud DLP."""
    
    DEFAULT_INFO_TYPES = [
    # Nombres y apellidos
    "PERSON_NAME",
    "FIRST_NAME", 
    "LAST_NAME",
    
    # Correos electrónicos
    "EMAIL_ADDRESS",
    
    # Teléfonos/Celular
    "PHONE_NUMBER",
    
    # Fechas de nacimiento
    "DATE_OF_BIRTH",
    
    # Direcciones domiciliarias
    "STREET_ADDRESS",
    "LOCATION",
    
    # DNI/CE/Pasaporte
    "PERU_DNI_NUMBER",
    "PASSPORT",
    
    # Números de cuenta bancaria
    "IBAN_CODE",
    "SWIFT_CODE",
    "FINANCIAL_ACCOUNT_NUMBER",
    
    # Números de tarjeta de crédito
    "CREDIT_CARD_NUMBER",
    
    # Diagnóstico médico
    "MEDICAL_RECORD_NUMBER",
    "MEDICAL_TERM",
]
    
    def __init__(self, project_id: Optional[str] = None, location: Optional[str] = None):
        self.project_id = project_id or config.PROJECT_ID
        self.location = location or config.LOCATION
        self.parent = f"projects/{self.project_id}/locations/{self.location}"
        self._client = None
    
    @property
    def client(self) -> dlp_v2.DlpServiceClient:
        """Lazy initialization del cliente DLP."""
        if self._client is None:
            self._client = dlp_v2.DlpServiceClient()
        return self._client
    
    def obfuscate_text(
        self, 
        text: str, 
        info_types: Optional[List[str]] = None,
        mask_char: str = "*",
        min_likelihood: str = "POSSIBLE",
        person_name_strategy: str = "mask",
        person_name_dictionary: Optional[List[str]] = None
    ) -> str:
        """Ofusca texto sensible.
        
        Args:
            text: Texto a ofuscar
            info_types: Tipos de información a detectar (usa DEFAULT_INFO_TYPES si es None)
            mask_char: Carácter para enmascarar
            min_likelihood: Nivel mínimo de confianza
            person_name_strategy: "mask" o "dictionary" para nombres de persona
            person_name_dictionary: Lista de nombres de reemplazo
            
        Returns:
            Texto ofuscado
        """
        if not text:
            return text
            
        info_types = info_types or self.DEFAULT_INFO_TYPES
        
        inspect_config = self._build_inspect_config(info_types, min_likelihood)
        deid_config = self._build_deidentify_config(
            info_types, mask_char, person_name_strategy, person_name_dictionary
        )
        
        response = self.client.deidentify_content(
            request={
                "parent": self.parent,
                "deidentify_config": deid_config,
                "inspect_config": inspect_config,
                "item": {"value": text},
            }
        )
        return response.item.value
    
    def inspect_text(
        self, 
        text: str, 
        info_types: Optional[List[str]] = None,
        min_likelihood: str = "POSSIBLE"
    ) -> List[dlp_v2.Finding]:
        """Inspecciona texto para encontrar datos sensibles.
        
        Args:
            text: Texto a inspeccionar
            info_types: Tipos de información a detectar
            min_likelihood: Nivel mínimo de confianza
            
        Returns:
            Lista de hallazgos
        """
        if not text:
            return []
            
        info_types = info_types or self.DEFAULT_INFO_TYPES
        inspect_config = self._build_inspect_config(info_types, min_likelihood)
        
        response = self.client.inspect_content(
            request={
                "parent": self.parent,
                "inspect_config": inspect_config,
                "item": {"value": text},
            }
        )
        return list(response.result.findings or [])
    
    def list_info_types(
        self,
        language_code: str = "es-MX",
        result_filter: str = "supported_by=INSPECT",
        location: str = "global",
    ) -> List[Tuple[str, str]]:
        """Lista tipos de información disponibles.
        
        Returns:
            Lista de tuplas (name, display_name)
        """
        parent = f"locations/{location}"
        response = self.client.list_info_types(
            request={
                "parent": parent,
                "language_code": language_code,
                "filter": result_filter,
            }
        )
        return [(it.name, it.display_name) for it in response.info_types]
    
    def _build_inspect_config(self, info_types: Iterable[str], min_likelihood: str) -> Dict[str, Any]:
        """Construye configuración de inspección."""
        return {
            "info_types": [{"name": it} for it in info_types],
            "min_likelihood": getattr(
                dlp_v2.Likelihood, min_likelihood.upper(), dlp_v2.Likelihood.POSSIBLE
            ),
        }
    
    def _build_deidentify_config(
        self,
        info_types: Iterable[str],
        mask_char: str,
        person_name_strategy: str = "mask",
        person_name_dictionary: Optional[List[str]] = None,
    ) -> Dict[str, Any]:
        """Construye configuración de desidentificación."""
        info_types_list = list(info_types)
        person_name = "PERSON_NAME"
        other_types = [it for it in info_types_list if it != person_name]
        transformations = []

        if person_name_strategy == "dictionary" and person_name_dictionary:
            transformations.append({
                "info_types": [{"name": person_name}],
                "primitive_transformation": {
                    "replace_dictionary_config": {
                        "word_list": {"words": list(person_name_dictionary)}
                    }
                },
            })
            masked_types = other_types
        else:
            masked_types = info_types_list

        if masked_types:
            transformations.append({
                "info_types": [{"name": it} for it in masked_types],
                "primitive_transformation": {
                    "character_mask_config": {
                        "masking_character": mask_char,
                        "number_to_mask": 0,
                    }
                },
            })

        return {"info_type_transformations": {"transformations": transformations}}
    
protector = DataSensitiveProtector()