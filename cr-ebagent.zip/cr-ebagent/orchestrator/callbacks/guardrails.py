import json
import logging
from typing import Optional
from google.adk.models import LlmRequest, LlmResponse
from google.adk.agents.callback_context import CallbackContext
from .utils.guardrails_checker import GuardrailsChecker

logger = logging.getLogger("guardrails")

# Global instance
_guardrails = GuardrailsChecker()

def guardrails_before_model_callback(
    callback_context: CallbackContext,
    llm_request: LlmRequest
) -> Optional[LlmResponse]:
    """Guardrails callback to check content safety before model execution."""

    # Extract user text from request
    user_text = ""
    if llm_request.contents and llm_request.contents[-1].parts:
        user_text = getattr(llm_request.contents[-1].parts[0], "text", "") or ""

    if not user_text:
        return None  # Allow empty requests

    # Check content safety and classify
    is_safe, reasoning, classification = _guardrails.check_content(user_text)

    # Log guardrails decision with classification
    logger.info(json.dumps({
        "event": "guardrail_check",
        "agent_name": callback_context.agent_name,
        "invocation_id": callback_context.invocation_id,
        "decision": "safe" if is_safe else "unsafe",
        "reasoning": reasoning,
        "classification": classification,
        "user_text_length": len(user_text)
    }))

    # Block unsafe content
    if not is_safe:
        blocked_response = "Lo siento, no puedo ayudarte con esa consulta. Por favor, reformula tu pregunta."
        return LlmResponse(
            content={"role": "model", "parts": [{"text": blocked_response}]}
        )

    return None  # Allow safe content to proceed