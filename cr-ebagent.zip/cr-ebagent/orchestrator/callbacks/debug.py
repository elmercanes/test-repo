import json
import uuid
import time
from google.adk.models import LlmResponse, LlmRequest
from google.adk.agents.callback_context import CallbackContext
from google.adk.tools.tool_context import ToolContext
from google.adk.tools.base_tool import BaseTool
from .utils.cost_tracker import track_model_call
from typing import Optional, Dict, Any
from datetime import datetime
import pytz
import logging
import google.cloud.logging
import os

# Set up logging
logger = logging.getLogger("agent_monitoring")
logger.setLevel(logging.INFO)

def setup_cloud_logging():
    """Set up Google Cloud Logging client"""
    try:
        client = google.cloud.logging.Client()
        client.setup_logging(
            name="agent_monitoring",
            resource=google.cloud.logging.Resource(
                type="aiplatform.googleapis.com/ReasoningEngine",
                labels={
                    "location": os.environ.get("GOOGLE_CLOUD_LOCATION", "us-central1"),
                    "resource_container": os.environ.get("GOOGLE_CLOUD_PROJECT_ID", ""),
                    "reasoning_engine_id": os.environ.get("GOOGLE_CLOUD_AGENT_ENGINE_ID", ""),
                },
            ),
        )
        return client
    except Exception as e:
        logger.error(f"Failed to setup cloud logging: {e}")
        return None

# Initialize cloud logging
cloud_client = setup_cloud_logging()

def get_peru_timestamp() -> str:
    """Returns current timestamp in Lima, Peru timezone in ISO 8601 format."""
    lima_tz = pytz.timezone("America/Lima")
    return datetime.now(lima_tz).isoformat()

def get_version() -> str:
    """Read version from deployment_metadata.json file."""
    version_file = "orchestrator/deployment_metadata.json"
    try:
        with open(version_file, "r") as f:
            metadata = json.load(f)
            return metadata.get("version", "unknown_version")
    except (FileNotFoundError, json.JSONDecodeError) as e:
        logger.warning(f"Could not read version from {version_file}: {e}")
        return "unknown_version"

# Global configuration
ENVIRONMENT = "dev"
MODEL = "estar_bien_agent"
VERSION = get_version()

class DebugLogger:
    """Advanced logging system for callbacks"""
    
    def __init__(self):
        self.logs = []
        self.metrics = {
            'total_calls': 0,
            'llm_calls': 0,
            'tool_calls': 0,
            'errors': 0,
            'avg_response_time': 0.0
        }
        self.timing_stack = []
    
    def log_event(self, event_type: str, data: Dict, level: str = 'INFO'):
        """Register an event with timestamp"""
        timestamp = datetime.now().isoformat()
        log_entry = {
            'timestamp': timestamp,
            'event_type': event_type,
            'level': level,
            'data': data
        }
        self.logs.append(log_entry)
        
        # Log with appropriate level
        log_message = f"{event_type}: {data}"
        getattr(logger, level.lower(), logger.info)(log_message)
    
    def start_timing(self, operation: str):
        """Start timer for an operation"""
        self.timing_stack.append({
            'operation': operation,
            'start_time': time.time()
        })
    
    def end_timing(self, operation: str) -> float:
        """End timer and log duration"""
        if self.timing_stack and self.timing_stack[-1]['operation'] == operation:
            timing_info = self.timing_stack.pop()
            duration = time.time() - timing_info['start_time']
            self.log_event('TIMING', {
                'operation': operation,
                'duration_ms': round(duration * 1000, 2)
            })
            return duration
        return 0.0
    
    def update_metrics(self, metric_name: str, value: float = 1):
        """Update metrics"""
        if metric_name == 'avg_response_time':
            current_avg = self.metrics[metric_name]
            total_calls = self.metrics['total_calls']
            self.metrics[metric_name] = ((current_avg * (total_calls - 1)) + value) / total_calls
        elif metric_name in self.metrics:
            self.metrics[metric_name] += value
    


# Global instances
debug_logger = DebugLogger()
_context_storage = {}

def generate_trace_id() -> str:
    return str(uuid.uuid4())

def _get_context_key(callback_context, operation_type=""):
    """Generate unique key for current context"""
    return f"{callback_context.agent_name}_{callback_context.invocation_id}_{operation_type}"

def _extract_session_info(callback_context):
    """Safely extract session information"""
    session_id = user_id = None
    try:
        if (hasattr(callback_context, '_invocation_context') and 
            callback_context._invocation_context and
            hasattr(callback_context._invocation_context, 'session') and
            callback_context._invocation_context.session):
            session_id = callback_context._invocation_context.session.id
            user_id = callback_context._invocation_context.session.user_id
    except AttributeError:
        pass
    return user_id, session_id

def _log_structured(data: Dict):
    try:
        logger.info(json.dumps(data, default=str))
    except Exception as e:
        logger.warning(f"Failed to log structured data: {e}")



# Agent Callbacks
def debug_before_agent_callback(callback_context: CallbackContext) -> Optional[Any]:
    """Callback before executing an agent"""
    agent_name = callback_context.agent_name
    trace_id = generate_trace_id()
    user_id, session_id = _extract_session_info(callback_context)
    
    # Store context information
    context_key = _get_context_key(callback_context, "agent")
    _context_storage[context_key] = {
        'trace_id': trace_id,
        'start_time': time.time()
    }
    
    log_data = {
        "agent_name": agent_name,
        "user_id": user_id,
        "session_id": session_id,
        "trace_id": trace_id,
        "event": "agent_start",
        "invocation_id": callback_context.invocation_id,
        "state_keys": list(callback_context.state.to_dict().keys()) if callback_context.state else [],
        "env": ENVIRONMENT,
        "model": MODEL,
        "timestamp": get_peru_timestamp(),
        "version": VERSION
    }
    
    _log_structured(log_data)
    debug_logger.start_timing('agent_execution')
    debug_logger.update_metrics('total_calls')
    return None

def debug_after_agent_callback(callback_context: CallbackContext) -> Optional[Any]:
    """Callback after executing an agent"""
    agent_name = callback_context.agent_name
    user_id, session_id = _extract_session_info(callback_context)
    
    # Retrieve context information
    context_key = _get_context_key(callback_context, "agent")
    context_info = _context_storage.pop(context_key, {})
    trace_id = context_info.get('trace_id', generate_trace_id())
    
    # Calculate execution time
    execution_time_ms = 0
    if 'start_time' in context_info:
        execution_time_ms = round((time.time() - context_info['start_time']) * 1000, 2)
    
    log_data = {
        "agent_name": agent_name,
        "user_id": user_id,
        "session_id": session_id,
        "trace_id": trace_id,
        "event": "agent_end",
        "invocation_id": callback_context.invocation_id,
        "execution_time_ms": execution_time_ms,
        "env": ENVIRONMENT,
        "model": MODEL,
        "timestamp": get_peru_timestamp(),
        "version": VERSION
    }
    
    _log_structured(log_data)
    
    # Update debug metrics
    duration = debug_logger.end_timing('agent_execution')
    debug_logger.update_metrics('avg_response_time', duration)
    return None

# Model Callbacks
def debug_before_model_callback(callback_context: CallbackContext, llm_request: LlmRequest) -> Optional[LlmResponse]:
    """Callback before calling LLM model"""
    agent_name = callback_context.agent_name
    trace_id = generate_trace_id()
    user_id, session_id = _extract_session_info(callback_context)
    
    # Extract request information
    last_input = llm_request.contents[-1].parts[0].text if llm_request.contents else ""
    message_count = len(llm_request.contents)
    model_name = getattr(llm_request, 'model', None)
    
    # Model configuration
    config = {}
    if llm_request.config:
        config = {
            "temperature": llm_request.config.temperature,
            "max_output_tokens": llm_request.config.max_output_tokens
        }
    
    # Store context information
    context_key = _get_context_key(callback_context, "model")
    _context_storage[context_key] = {
        'trace_id': trace_id,
        'start_time': time.time(),
        'model_name': model_name
    }
    
    log_data = {
        "agent_name": agent_name,
        "user_id": user_id,
        "session_id": session_id,
        "trace_id": trace_id,
        "event": "input",
        "text": last_input,
        "model_name": model_name,
        "message_count": message_count,
        "invocation_id": callback_context.invocation_id,
        "config": config,
        "env": ENVIRONMENT,
        "model": MODEL,
        "timestamp": get_peru_timestamp(),
        "version": VERSION
    }
    
    _log_structured(log_data)
    debug_logger.start_timing('llm_call')
    debug_logger.update_metrics('llm_calls')
    return None

def debug_after_model_callback(callback_context: CallbackContext, llm_response: LlmResponse) -> Optional[LlmResponse]:
    """Callback after receiving LLM model response"""
    agent_name = callback_context.agent_name
    user_id, session_id = _extract_session_info(callback_context)
    
    # Retrieve context information
    context_key = _get_context_key(callback_context, "model")
    context_info = _context_storage.pop(context_key, {})
    trace_id = context_info.get('trace_id', generate_trace_id())
    model_name = context_info.get('model_name')
    
    # Calculate response time
    response_time_ms = 0
    if 'start_time' in context_info:
        response_time_ms = round((time.time() - context_info['start_time']) * 1000, 2)
    
    # Extract response information
    output = ""
    function_calls = []
    if llm_response.content and llm_response.content.parts:
        output = llm_response.content.parts[0].text or ""
        
        # Look for function calls
        for part in llm_response.content.parts:
            if hasattr(part, 'function_call') and part.function_call:
                function_calls.append(part.function_call.name)
    
    # Track real costs
    cost_info = None
    try:
        cost_info = track_model_call(agent_name, model_name, llm_response)
    except Exception as e:
        logger.warning(f"Error calculating costs: {e}")
    
    # Extract token and cost information
    prompt_tokens = candidates_tokens = total_tokens = call_cost = 0
    if cost_info:
        tokens = cost_info['token_usage']
        costs = cost_info['costs']
        prompt_tokens = tokens.get('input_tokens', 0)
        candidates_tokens = tokens.get('output_tokens', 0)
        total_tokens = tokens.get('total_tokens', 0)
        call_cost = round(costs.get('total_cost', 0.0), 6)
    
    log_data = {
        "agent_name": agent_name,
        "user_id": user_id,
        "session_id": session_id,
        "trace_id": trace_id,
        "event": "output",
        "text": output,
        "model_name": model_name,
        "response_time_ms": response_time_ms,
        "invocation_id": callback_context.invocation_id,
        "prompt_token_count": prompt_tokens,
        "candidates_token_count": candidates_tokens,
        "total_token_count": total_tokens,
        "call_cost": call_cost,
        "function_calls": function_calls,
        "response_length": len(output),
        "env": ENVIRONMENT,
        "model": MODEL,
        "timestamp": get_peru_timestamp(),
        "version": VERSION
    }
    
    _log_structured(log_data)
    debug_logger.end_timing('llm_call')
    return None

# Tool Callbacks
def debug_before_tool_callback(tool: BaseTool, args: Dict[str, Any], tool_context: ToolContext) -> Optional[Dict]:
    """Callback before executing a tool"""
    tool_name = tool.name
    agent_name = tool_context.agent_name
    trace_id = generate_trace_id()
    user_id, session_id = _extract_session_info(tool_context)
    
    # Store context information
    context_key = f"{agent_name}_{tool_name}_{tool_context.invocation_id}"

    _context_storage[context_key] = {
        'trace_id': trace_id,
        'start_time': time.time()
    }
    
    log_data = {
        "tool_name": tool_name,
        "agent_name": agent_name,
        "user_id": user_id,
        "session_id": session_id,
        "trace_id": trace_id,
        "event": "tool_invoked",
        "invocation_id": tool_context.invocation_id,
        "tool_args": args,
        "state_keys": list(tool_context.state.to_dict().keys()) if tool_context.state else [],
        "env": ENVIRONMENT,
        "model": MODEL,
        "timestamp": get_peru_timestamp(),
        "version": VERSION
    }
    
    _log_structured(log_data)
    logger.info(f"tool-{tool_name} invoked by agent-{agent_name}")
    debug_logger.start_timing(f'tool_{tool.name}')
    debug_logger.update_metrics('tool_calls')
    return None

def debug_after_tool_callback(tool: BaseTool, args: Dict[str, Any], tool_context: ToolContext, tool_response: Dict) -> Optional[Dict]:
    """Callback after executing a tool"""
    tool_name = tool.name
    agent_name = tool_context.agent_name
    user_id, session_id = _extract_session_info(tool_context)
    
    # Retrieve context information
    context_key = f"{agent_name}_{tool_name}_{tool_context.invocation_id}"

    context_info = _context_storage.pop(context_key, {})
    trace_id = context_info.get('trace_id', generate_trace_id())
    
    # Calculate response time
    response_time_ms = 0
    if 'start_time' in context_info:
        response_time_ms = round((time.time() - context_info['start_time']) * 1000, 2)
    
    # Determine tool success
    success = tool_response is not None and (not isinstance(tool_response, dict) or 'error' not in tool_response)
    
    log_data = {
        "tool_name": tool_name,
        "agent_name": agent_name,
        "user_id": user_id,
        "session_id": session_id,
        "trace_id": trace_id,
        "event": "tool_response",
        "invocation_id": tool_context.invocation_id,
        "tool_args": args,
        "tool_response": tool_response,
        "response_time_ms": response_time_ms,
        "response_size": len(str(tool_response)) if tool_response else 0,
        "success": success,
        "env": ENVIRONMENT,
        "model": MODEL,
        "timestamp": get_peru_timestamp(),
        "version": VERSION
    }
    
    _log_structured(log_data)
    debug_logger.end_timing(f'tool_{tool.name}')
    if not success:
        debug_logger.update_metrics('errors')
    return None