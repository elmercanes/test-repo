"""
LiteLLM Model Configuration for Rimac Agents (lazy & CI-safe)
"""
from __future__ import annotations

import os
from typing import Optional, Dict
from functools import lru_cache

from dotenv import load_dotenv
from google.cloud import secretmanager
import litellm
from google.adk.models.lite_llm import LiteLlm

# Cargar .env en desarrollo local (no rompe en CI)
load_dotenv()

# ---- Flags de entorno para CI / Tests ----------------------------------------
def _gcp_disabled() -> bool:
    # Desactiva acceso a GCP en CI/tests
    return (
        os.getenv("SKIP_GCP_AUTH") == "1"
        or os.getenv("CI", "").lower() == "true"
        or "PYTEST_CURRENT_TEST" in os.environ
    )

# ---- Secret Manager ----------------------------------------------------------
class SecretsManager:
    def __init__(self, project_id: str, client: Optional[secretmanager.SecretManagerServiceClient] = None):
        self.project_id = project_id
        self._client = client  # inyectable/mokeable

    def _get_client(self) -> secretmanager.SecretManagerServiceClient:
        if self._client is None:
            if _gcp_disabled():
                # Ayuda a detectar usos indebidos durante tests
                raise RuntimeError("GCP auth disabled for tests/CI (SKIP_GCP_AUTH/CI)")
            self._client = secretmanager.SecretManagerServiceClient()
        return self._client

    def get_secret_payload(self, secret_id: str, version_id: str = "latest") -> str:
        client = self._get_client()
        # Usar nombre de recurso explícito (API moderna)
        name = f"projects/{self.project_id}/secrets/{secret_id}/versions/{version_id}"
        try:
            response = client.access_secret_version(request={"name": name})
            return response.payload.data.decode("utf-8")
        except Exception as e:
            print(f"Error al acceder al secreto '{secret_id}': {e}")
            raise

# ---- Lista de secretos esperados --------------------------------------------
SECRET_NAMES = [
    "GOOGLE_GENAI_USE_VERTEXAI",
    "GOOGLE_CLOUD_PROJECT",
    "GOOGLE_CLOUD_LOCATION",
    "STAGING_BUCKET",
    "ORCHESTRATOR_TEMPERATURE",
    "ORCHESTRATOR_MAX_OUTPUT_TOKENS",
    "ORCHESTRATOR_TOP_K",
    "ORCHESTRATOR_TOP_P"
]

# ---- Carga perezosa de secretos ---------------------------------------------
def _project_id_from_env() -> Optional[str]:
    # Permite override por env y evita hardcode
    return (
        os.getenv("GOOGLE_CLOUD_PROJECT")
        or os.getenv("GCP_PROJECT")
        or os.getenv("PROJECT_ID")
        or os.getenv("GOOGLE_PROJECT")
    )

@lru_cache(maxsize=1)
def _load_secrets_if_needed() -> Dict[str, str]:
    """
    Descarga secretos solo cuando hagan falta y si no estamos en CI/tests.
    Idempotente gracias al cache.
    """
    loaded: Dict[str, str] = {}
    
    print("[DEBUG] Iniciando carga de secretos")
    print(f"[DEBUG] SKIP_GCP_AUTH={os.getenv('SKIP_GCP_AUTH')}")
    print(f"[DEBUG] CI={os.getenv('CI')}")
    print(f"[DEBUG] PYTEST_CURRENT_TEST={os.getenv('PYTEST_CURRENT_TEST')}")

    if _gcp_disabled():
        print("[DEBUG] GCP está deshabilitado por flags de entorno")
        # En CI/tests no hacemos nada; los tests pueden setear env o mockear.
        return loaded

    project_id = _project_id_from_env() or "rs-nprd-dlk-saia-gnai-dev-7251"  # valor por defecto si no hay env
    print(f"[DEBUG] Usando project_id: {project_id}")
    sm = SecretsManager(project_id)

    for name in SECRET_NAMES:
        # No sobreescribir si ya viene de .env/variables del pipeline
        if os.getenv(name) is not None:
            print(f"[DEBUG] Variable {name} ya existe en env, no se carga de Secret Manager")
            continue
        try:
            print(f"[DEBUG] Intentando cargar secreto: {name}")
            val = sm.get_secret_payload(name)
            os.environ[name] = val
            loaded[name] = val
            print(f"[DEBUG] Secreto {name} cargado exitosamente")
        except Exception as e:
            # No levantar en caliente para no romper en runtime si algunos no son críticos.
            # Si son obligatorios para tu app, cambia a "raise".
            print(f"[ERROR] No se pudo cargar secreto {name}: {e}")
    return loaded

# ---- Fábrica de modelos LiteLLM ---------------------------------------------
def get_litellm_model(model_name: str = "vertex_ai/gemini-2.5-flash") -> LiteLlm:
    # Activa proxy cuando realmente vamos a crear el modelo
    litellm.use_litellm_proxy = False
    # Carga de secretos perezosa; en CI no hace nada
    _load_secrets_if_needed()
    return LiteLlm(model=model_name)

# ---- default_model (lazy proxy para compatibilidad) -------------------------
class _LazyModel:
    _instance: Optional[LiteLlm] = None

    def _get(self) -> LiteLlm:
        if self._instance is None:
            self._instance = get_litellm_model()
        return self._instance

    def __getattr__(self, item):
        return getattr(self._get(), item)

# Mantiene el símbolo pero sin instanciar en import-time
default_model = _LazyModel()
