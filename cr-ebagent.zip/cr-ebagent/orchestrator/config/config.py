"""
Centralized configuration management for RIMAC GenAI AIDA Service
Manages all environment variables across orchestrator and sub-agents
"""
import os
from typing import Optional
from dotenv import load_dotenv

load_dotenv()

class Config:
    """Centralized configuration class for all environment variables"""
    
    # LiteLLM Configuration (Orchestrator)
    @property
    def LITELLM_PROXY_API_KEY(self) -> Optional[str]:
        return os.getenv('LITELLM_PROXY_API_KEY')
    
    @property
    def GOOGLE_GENAI_USE_VERTEXAI(self) -> str:
        return os.getenv('GOOGLE_GENAI_USE_VERTEXAI', 'TRUE')

    @property
    def PROJECT_ID(self) -> str:
        return os.getenv('PROJECT_ID', '')

    @property
    def LOCATION(self) -> str:
        return os.getenv('LOCATION', 'us-central1')
    
    @property
    def GOOGLE_CLOUD_PROJECT(self) -> str:
        return os.getenv('GOOGLE_CLOUD_PROJECT', '')
    
    @property
    def GOOGLE_CLOUD_LOCATION(self) -> str:
        return os.getenv('GOOGLE_CLOUD_LOCATION', 'us-central1')
    
    @property
    def ORCHESTRATOR_TEMPERATURE(self) -> float:
        return float(os.getenv('ORCHESTRATOR_TEMPERATURE', '0.4'))

    @property
    def ORCHESTRATOR_MAX_OUTPUT_TOKENS(self) -> int:
        return int(os.getenv('ORCHESTRATOR_MAX_OUTPUT_TOKENS', '8192'))

    @property
    def ORCHESTRATOR_TOP_K(self) -> int:
        return int(os.getenv('ORCHESTRATOR_TOP_K', '1'))

    @property
    def ORCHESTRATOR_TOP_P(self) -> float:
        return float(os.getenv('ORCHESTRATOR_TOP_P', '0.5'))

# Global configuration instance
config = Config()